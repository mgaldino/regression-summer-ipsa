README.TXT
2004 American National Election Study (2004.TN)
August 16, 2005 release


This release includes the following files:

ASCII CODEBOOK FILES:
--------------------
    nes04int.txt        (INTRODUCTION)
    nes04var.txt        (VARIABLE DOCUMENTATION)
    nes04app.txt        (APPENDICES)


ASCII RAW DATA FILE:
--------------------
    nes04dat.txt  


SAS STATEMENT FILES:  (in .ZIP file 'sas.zip')
-------------------- 
    nes04run.sas  
    nes04md.sas
    nes04lab.sas
    nes04fmt.sas
    nes04col.sas
    nes04cod.sas
These statement files are used to create a SAS system file; 
please read the comment material in the SAS 'run' file first.


SPSS STATEMENT FILES:  (in .ZIP file 'spss.zip')
---------------------
    nes04run.sps
    nes04col.sps
    nes04lab.sps
    nes04md.sps
    nes04cod.sps
These statement files are used to create a SPSS system file; 
please read the comment material in the SPSS 'run' file first.



STATA STATEMENT FILES:  (in .ZIP file 'sas.zip')
----------------------
    nes04run.do
    nes04cod.do
    nes04fmt.do
    nes04col.dct
    nes04lab.do
    nes04md.do
These statements are used to create a STATA system file; please read the 
comment material in the STATA 'run' file first.



ADDITIONAL NOTES:
-----------------
- Updates concerning the release are posted on the NES website at:
  http://www.umich.edu/~nes
- Please contact nes at 'nes@umich.edu' with any questions you might have.